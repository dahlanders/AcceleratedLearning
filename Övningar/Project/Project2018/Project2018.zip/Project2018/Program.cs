﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

class Material
{
    public string Name { get; set; }
    public double UValue { get; set; }
}
class MaterialWithThickness
{
    public string Name { get; set; }
    public double UValue { get; set; }
    public double Thickness { get; set; }
}
class Program

{
    static void Main()
    {
        CultureInfo info = CultureInfo.GetCultureInfo("us-US");

        List<Material> materiallist = new List<Material>();

        // The files used in this example are created in the topic
        // How to: Write to a Text File. You can change the path and
        // file name to substitute text files of your own.

        // Example #1
        // Read the file as one string.
        string text = System.IO.File.ReadAllText(@"C:\Project\AcceleratedLearning\Övningar\Project\Project2018\material.csv");

        //// Display the file contents to the console. Variable text is a string.
        // System.Console.WriteLine("Contents of WriteText.txt = {0}", text);

        // Example #2
        // Read each line of the file into a string array. Each element
        // of the array is one line of the file.
        string[] lines = System.IO.File.ReadAllLines(@"C:\Project\AcceleratedLearning\Övningar\Project\Project2018\material.csv");

        // Display the file contents by using a foreach loop.
        //System.Console.WriteLine("Contents of WriteLines2.txt = ");


        // 1. LÄS IN MATERILA

        foreach (string line in lines)
        {

            var xsplit = line.Split('|');

            var newmaterial = new Material();
            newmaterial.Name = xsplit[0];
          
            newmaterial.UValue = Double.Parse(xsplit[1],info);
            materiallist.Add(newmaterial);

        }

        // 2. INPUT FÅRE ANVNDARE


        string printedmaterial;

        var usersChocie = new List<Material>();



        while (true)
        {
            Console.Write("Skriv in ditt materail: ");
            printedmaterial = Console.ReadLine();
            var materialArray = printedmaterial.Split('|');
            bool allUserMaterialInputIsOkey = true;

            foreach (var material in materialArray)
            {
                if (ValidationOfMaterial(material, materiallist) == false)
                {
                    Console.WriteLine("E du goo eller!!");
                    allUserMaterialInputIsOkey = false;
                }
              
            }
            if (allUserMaterialInputIsOkey == true)
            {
                break;
            }
       

        }

        string tjocklekMaterial;

        while (true)
        {
            Console.Write("Skriv in tjockleken på materialet i meter. (exempel 0.02 : 0.1): ");
            tjocklekMaterial = Console.ReadLine();
            string[] values = tjocklekMaterial.Split("|");
            double d1 = double.Parse(values[0], CultureInfo.InvariantCulture);
            foreach (var tjocklek in values)

                if (double.Parse(tjocklek,info) >= 1)
            {
                Console.WriteLine("Är du från Strängnäs???");
                continue;
            }
            break;
        }

        double uValue = GetUValue(printedmaterial, materiallist);

        var myMaterial = new MaterialWithThickness();
        

        
        myMaterial.Name = printedmaterial;
        myMaterial.Thickness = Double.Parse(tjocklekMaterial,info);
        myMaterial.UValue = uValue;

        var myWall = new List<MaterialWithThickness>();
        myWall.Add(myMaterial);

        var calculus = CalculateMyWall(myWall);


        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("Resultatet av dina angivna prylar: " + calculus.ToString("F"));
        Console.ResetColor();

        Console.WriteLine("Press any key to exit.");
        System.Console.ReadKey();
    }

    private static double CalculateMyWall(List<MaterialWithThickness> myWall)
    {
        foreach (var materialwiththickness in myWall)
        {
            var uvresult = materialwiththickness.UValue;
            var thickness = materialwiththickness.Thickness;

            return materialwiththickness.Thickness / materialwiththickness.UValue;

        }
        return 0;
    }

    private static double GetUValue(string printedmaterial, List<Material> materiallist)
    {
        foreach (var material in materiallist)
        {
            if (printedmaterial == material.Name)
                return material.UValue;

        }
        return 0;


    }
    public static bool ValidationOfMaterial(string materialname, List<Material> materiallist)
    {
        bool materialIsInList = false;

        foreach (var matrial in materiallist)
        {
            if (matrial.Name.ToLower() == materialname.ToLower())
            {

                materialIsInList = true;
                break;
            }
        }

        return materialIsInList;


    }
}
